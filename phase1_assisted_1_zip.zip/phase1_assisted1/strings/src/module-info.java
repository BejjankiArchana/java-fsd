/**
 * 
 */
/**
 * 
 */
module strings {
}